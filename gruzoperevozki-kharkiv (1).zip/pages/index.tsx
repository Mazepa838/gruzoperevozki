
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Instagram, Send } from "lucide-react";
import Image from "next/image";

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center px-4 py-8 space-y-10">
      <h1 className="text-4xl font-bold text-center text-gray-800">
        Грузоперевозки по Харькову и области
      </h1>
      <p className="text-lg text-center text-gray-600 max-w-xl">
        Надёжные перевозки до 2 тонн по городу и за его пределами. Минимальный заказ — 2 часа. Работаем быстро, аккуратно и по доступной цене.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl">
        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-6 space-y-4">
            <h2 className="text-2xl font-semibold text-gray-800">Услуги</h2>
            <ul className="list-disc list-inside text-gray-700 space-y-1">
              <li>Грузоперевозки до 2 тонн</li>
              <li>Квартирные и офисные переезды</li>
              <li>Вывоз мусора</li>
              <li>Доставка крупногабаритных грузов</li>
              <li>Услуги грузчиков</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-6 space-y-4">
            <h2 className="text-2xl font-semibold text-gray-800">Цены</h2>
            <ul className="text-gray-700 space-y-1">
              <li>450 грн/час по Харькову</li>
              <li>Минимальный заказ — 2 часа</li>
              <li>18 грн/км за городом</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-2xl font-bold text-gray-800">Галерея</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl">
        <Image src="/truck1.jpg" alt="Газель тентованная 1" width={400} height={250} className="rounded-2xl shadow-md object-cover w-full h-auto" />
        <Image src="/truck2.jpg" alt="Газель тентованная 2" width={400} height={250} className="rounded-2xl shadow-md object-cover w-full h-auto" />
        <Image src="/truck3.jpg" alt="Газель тентованная 3" width={400} height={250} className="rounded-2xl shadow-md object-cover w-full h-auto" />
      </div>

      <Card className="rounded-2xl shadow-md max-w-2xl w-full">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold text-gray-800">Контакты</h2>
          <div className="flex flex-col space-y-2 text-gray-700">
            <div className="flex items-center gap-2"><Phone className="w-5 h-5" /> <span>093 055 1043</span></div>
            <div className="flex items-center gap-2"><Phone className="w-5 h-5" /> <span>097 189 1623</span></div>
            <div className="flex items-center gap-2"><Instagram className="w-5 h-5" /> <a href="https://www.instagram.com/transportation.kh?igsh=MTJ1ejA1djYxdXJ2aA==" target="_blank" rel="noopener noreferrer" className="underline">Instagram</a></div>
            <div className="flex items-center gap-2"><Send className="w-5 h-5" /> <a href="https://t.me/Gryzoperevozkikharkiv" className="underline">Telegram</a></div>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
